package com.rs.aivideoeditorpro.engine

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.rs.aivideoeditorpro.domain.model.AudioTrackClip
import com.rs.aivideoeditorpro.domain.model.CaptionSegment
import com.rs.aivideoeditorpro.domain.model.ExportSettings
import com.rs.aivideoeditorpro.domain.model.OverlayElement
import com.rs.aivideoeditorpro.domain.model.VideoClip
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import kotlin.coroutines.resume
import kotlin.math.abs

class MediaProcessorEngine(private val context: Context) {

    suspend fun exportTimeline(
        videoClips: List<VideoClip>,
        audioClips: List<AudioTrackClip>,
        overlays: List<OverlayElement>,
        outputFile: File,
        settings: ExportSettings,
        onProgress: (Float) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        val totalDurationMs = videoClips.sumOf { it.effectiveDurationMs }.coerceAtLeast(1L)
        val command = FFmpegCommandBuilder.buildExportCommand(
            videoClips = videoClips,
            audioClips = audioClips,
            overlays = overlays,
            outputFile = outputFile,
            settings = settings
        )

        suspendCancellableCoroutine { continuation ->
            val session = FFmpegKit.executeAsync(
                command,
                { completedSession ->
                    if (ReturnCode.isSuccess(completedSession.returnCode)) {
                        onProgress(1f)
                        continuation.resume(Result.success(outputFile))
                    } else {
                        continuation.resume(
                            Result.failure(
                                IllegalStateException("FFmpeg export failed: ${completedSession.failStackTrace}")
                            )
                        )
                    }
                },
                { _ -> },
                { statistics ->
                    val progress = (statistics.time.toFloat() / totalDurationMs.toFloat()).coerceIn(0f, 0.99f)
                    onProgress(progress)
                }
            )
            continuation.invokeOnCancellation { session.cancel() }
        }
    }

    suspend fun extractWaveformSamples(uri: Uri, bucketCount: Int = 64): List<Float> =
        withContext(Dispatchers.IO) {
            val extractor = MediaExtractor()
            val samples = MutableList(bucketCount) { 0.2f }
            try {
                extractor.setDataSource(context, uri, null)
                var audioTrackIndex = -1
                for (i in 0 until extractor.trackCount) {
                    val format = extractor.getTrackFormat(i)
                    val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                    if (mime.startsWith("audio/")) {
                        audioTrackIndex = i
                        break
                    }
                }
                if (audioTrackIndex >= 0) {
                    extractor.selectTrack(audioTrackIndex)
                    val buffer = ByteBuffer.allocate(32 * 1024)
                    var bucketIdx = 0
                    while (bucketIdx < bucketCount) {
                        val size = extractor.readSampleData(buffer, 0)
                        if (size < 0) break
                        var peak = 0
                        for (b in 0 until minOf(size, 512) step 2) {
                            val amp = abs(buffer.getShort(b).toInt())
                            if (amp > peak) peak = amp
                        }
                        samples[bucketIdx] = (peak / 32768f).coerceIn(0.08f, 1.0f)
                        bucketIdx++
                        extractor.advance()
                    }
                }
            } catch (_: Exception) {
                // Fallback neutral waveform
            } finally {
                extractor.release()
            }
            samples
        }

    fun generateAutoCaptions(videoClips: List<VideoClip>): List<CaptionSegment> {
        var cursorMs = 0L
        return videoClips.mapIndexed { index, clip ->
            val segment = CaptionSegment(
                text = "Scene ${index + 1}: ${clip.title}",
                startMs = cursorMs + 250L,
                endMs = (cursorMs + clip.effectiveDurationMs - 250L).coerceAtLeast(cursorMs + 800L)
            )
            cursorMs += clip.effectiveDurationMs
            segment
        }
    }
}
