package com.rs.aivideoeditorpro.engine

import com.rs.aivideoeditorpro.domain.model.AudioTrackClip
import com.rs.aivideoeditorpro.domain.model.ExportSettings
import com.rs.aivideoeditorpro.domain.model.FilterPreset
import com.rs.aivideoeditorpro.domain.model.OverlayElement
import com.rs.aivideoeditorpro.domain.model.TransitionType
import com.rs.aivideoeditorpro.domain.model.VideoClip
import java.io.File

object FFmpegCommandBuilder {

    fun buildExportCommand(
        videoClips: List<VideoClip>,
        audioClips: List<AudioTrackClip>,
        overlays: List<OverlayElement>,
        outputFile: File,
        settings: ExportSettings
    ): String {
        val inputs = StringBuilder()
        val filterGraph = StringBuilder()

        videoClips.forEachIndexed { index, clip ->
            val startSec = clip.trimStartMs / 1000.0
            val endSec = clip.trimEndMs / 1000.0
            inputs.append("-ss $startSec -to $endSec -i \"${clip.uri.path}\" ")

            val ptsFactor = 1.0f / clip.speed
            val eqFilter = buildColorAndPresetFilter(clip)
            val scaleFilter =
                "scale=${settings.resolution.width}:${settings.resolution.height}:force_original_aspect_ratio=decrease," +
                    "pad=${settings.resolution.width}:${settings.resolution.height}:(ow-iw)/2:(oh-ih)/2:color=#08090C"

            filterGraph.append("[$index:v]setpts=$ptsFactor*PTS,$scaleFilter,$eqFilter,fps=${settings.fps}[v$index];")
        }

        // Chain transitions or concatenate video streams
        var lastVideoLabel = "v0"
        var accumulatedOffsetSec = (videoClips.firstOrNull()?.effectiveDurationMs ?: 0L) / 1000.0

        for (i in 1 until videoClips.size) {
            val clip = videoClips[i]
            val outLabel = "vx$i"
            if (clip.transitionIn != TransitionType.NONE) {
                val transDurSec = (clip.transitionDurationMs / 1000.0).coerceAtMost(1.5)
                val offset = (accumulatedOffsetSec - transDurSec).coerceAtLeast(0.0)
                filterGraph.append(
                    "[$lastVideoLabel][v$i]xfade=transition=${clip.transitionIn.ffmpegName}:" +
                        "duration=$transDurSec:offset=$offset[$outLabel];"
                )
                accumulatedOffsetSec += (clip.effectiveDurationMs / 1000.0) - transDurSec
            } else {
                filterGraph.append("[$lastVideoLabel][v$i]concat=n=2:v=1:a=0[$outLabel];")
                accumulatedOffsetSec += clip.effectiveDurationMs / 1000.0
            }
            lastVideoLabel = outLabel
        }

        // Burn-in Text & Sticker Overlays
        overlays.forEachIndexed { idx, overlay ->
            val nextLabel = "vov$idx"
            val startSec = overlay.startMs / 1000.0
            val endSec = overlay.endMs / 1000.0
            val safeText = overlay.text.replace("'", "\\'")
            filterGraph.append(
                "[$lastVideoLabel]drawtext=text='$safeText':fontcolor=white:fontsize=48:" +
                    "x=(w*${overlay.normalizedX})-text_w/2:y=(h*${overlay.normalizedY})-text_h/2:" +
                    "enable='between(t,$startSec,$endSec)'[$nextLabel];"
            )
            lastVideoLabel = nextLabel
        }

        // Mix Audio Tracks if present
        val audioInputStartIndex = videoClips.size
        if (audioClips.isNotEmpty()) {
            val audioLabels = mutableListOf<String>()
            audioClips.forEachIndexed { idx, audio ->
                val inputIdx = audioInputStartIndex + idx
                inputs.append("-i \"${audio.uri.path}\" ")
                val delayMs = audio.startOffsetMs
                filterGraph.append(
                    "[$inputIdx:a]volume=${audio.volume},adelay=$delayMs|$delayMs[a$idx];"
                )
                audioLabels.add("[a$idx]")
            }
            filterGraph.append("${audioLabels.joinToString("")}amix=inputs=${audioClips.size}:duration=longest[aout];")
        }

        val codec = if (settings.useHevc) "libx265" else "libx264"
        val mapAudio = if (audioClips.isNotEmpty()) "-map \"[aout]\"" else ""

        return "$inputs-filter_complex \"${filterGraph.toString().trimEnd(';')}\" " +
            "-map \"[$lastVideoLabel]\" $mapAudio -c:v $codec -b:v ${settings.resolution.bitrate} " +
            "-preset fast -pix_fmt yuv420p -c:a aac -b:a 192k -y \"${outputFile.absolutePath}\""
    }

    private fun buildColorAndPresetFilter(clip: VideoClip): String {
        val grade = clip.colorGrade
        val presetFilter = when (clip.filterPreset) {
            FilterPreset.ORIGINAL -> ""
            FilterPreset.EMERALD_CINEMA -> ",colorbalance=gm=0.12:gs=0.06:bm=-0.05"
            FilterPreset.NEON_PINK -> ",colorbalance=rm=0.18:bm=0.22:gh=-0.08"
            FilterPreset.ORANGE_GRADE -> ",colorbalance=rs=0.16:gs=0.06:bs=-0.14"
            FilterPreset.NOIR -> ",hue=s=0"
        }
        return "eq=brightness=${grade.exposure * 0.25}:contrast=${grade.contrast}:saturation=${grade.saturation}$presetFilter"
    }
}
