package com.rs.aivideoeditorpro.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rs.aivideoeditorpro.domain.model.ExportResolution
import com.rs.aivideoeditorpro.domain.model.ExportSettings
import com.rs.aivideoeditorpro.ui.theme.EmeraldHighlight
import com.rs.aivideoeditorpro.ui.theme.HairlineBorder
import com.rs.aivideoeditorpro.ui.theme.OrangeAccent
import com.rs.aivideoeditorpro.ui.theme.PremiumBlack
import com.rs.aivideoeditorpro.ui.theme.StudioElevated
import com.rs.aivideoeditorpro.ui.theme.StudioSurface
import com.rs.aivideoeditorpro.ui.theme.TextPrimary
import com.rs.aivideoeditorpro.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportSheet(
    exportProgress: Float?,
    resultMessage: String?,
    onDismiss: () -> Unit,
    onStartExport: (ExportSettings) -> Unit
) {
    var selectedRes by remember { mutableStateOf(ExportResolution.UHD_4K) }
    var selectedFps by remember { mutableIntStateOf(60) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = StudioSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Export Master Video",
                color = TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExportResolution.entries.forEach { res ->
                    val selected = res == selectedRes
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selected) EmeraldHighlight.copy(alpha = 0.16f) else StudioElevated)
                            .border(
                                1.dp,
                                if (selected) EmeraldHighlight else HairlineBorder,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { selectedRes = res }
                            .padding(12.dp)
                    ) {
                        Text(res.label, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("${res.width}×${res.height}", color = TextSecondary, fontSize = 11.sp)
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(24, 30, 60).forEach { fps ->
                    val selected = fps == selectedFps
                    Text(
                        text = "$fps FPS",
                        color = if (selected) EmeraldHighlight else TextSecondary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(StudioElevated)
                            .border(1.dp, if (selected) EmeraldHighlight else HairlineBorder, RoundedCornerShape(6.dp))
                            .clickable { selectedFps = fps }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }

            if (exportProgress != null) {
                LinearProgressIndicator(
                    progress = { exportProgress },
                    modifier = Modifier.fillMaxWidth(),
                    color = OrangeAccent
                )
            }

            if (resultMessage != null) {
                Text(resultMessage, color = EmeraldHighlight, fontSize = 12.sp)
            }

            Button(
                onClick = { onStartExport(ExportSettings(selectedRes, selectedFps, true)) },
                enabled = exportProgress == null,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = OrangeAccent,
                    contentColor = PremiumBlack
                )
            ) {
                Text(
                    text = if (exportProgress == null) "Render ${selectedRes.label} MP4" else "Rendering...",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
