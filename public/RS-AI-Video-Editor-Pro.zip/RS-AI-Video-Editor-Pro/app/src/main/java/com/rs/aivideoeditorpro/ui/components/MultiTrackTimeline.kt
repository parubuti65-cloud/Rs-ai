package com.rs.aivideoeditorpro.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rs.aivideoeditorpro.domain.model.AudioTrackClip
import com.rs.aivideoeditorpro.domain.model.CaptionSegment
import com.rs.aivideoeditorpro.domain.model.VideoClip
import com.rs.aivideoeditorpro.ui.theme.EmeraldHighlight
import com.rs.aivideoeditorpro.ui.theme.HairlineBorder
import com.rs.aivideoeditorpro.ui.theme.NeonPinkEffect
import com.rs.aivideoeditorpro.ui.theme.OrangeAccent
import com.rs.aivideoeditorpro.ui.theme.StudioElevated
import com.rs.aivideoeditorpro.ui.theme.StudioSurface
import com.rs.aivideoeditorpro.ui.theme.TextPrimary
import com.rs.aivideoeditorpro.ui.theme.TextSecondary

@Composable
fun MultiTrackTimeline(
    videoClips: List<VideoClip>,
    audioClips: List<AudioTrackClip>,
    captions: List<CaptionSegment>,
    selectedClipId: String?,
    onSelectClip: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(StudioSurface)
            .border(1.dp, HairlineBorder)
            .padding(12.dp)
            .horizontalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // V1 Video Track
        Text("V1 Video", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            videoClips.forEach { clip ->
                val isSelected = clip.id == selectedClipId
                val widthDp = ((clip.effectiveDurationMs / 1000f) * 32f).coerceAtLeast(64f).dp
                Box(
                    modifier = Modifier
                        .width(widthDp)
                        .height(48.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(StudioElevated)
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) EmeraldHighlight else HairlineBorder,
                            shape = RoundedCornerShape(6.dp)
                        )
                        .clickable { onSelectClip(clip.id) }
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(
                        text = clip.title,
                        color = TextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1
                    )
                }
            }
        }

        // A1 Audio Track with Waveform Canvas
        Text("A1 Music & Audio", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            audioClips.forEach { audio ->
                val widthDp = ((audio.durationMs / 1000f) * 32f).coerceAtLeast(80f).dp
                Box(
                    modifier = Modifier
                        .width(widthDp)
                        .height(38.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0x2610B981))
                        .border(1.dp, EmeraldHighlight.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Canvas(modifier = Modifier.fillMaxWidth().fillMaxHeight(0.75f)) {
                        val bars = audio.waveformSamples.ifEmpty { listOf(0.4f, 0.7f, 0.5f, 0.9f, 0.6f) }
                        val step = size.width / bars.size.coerceAtLeast(1)
                        bars.forEachIndexed { idx, amp ->
                            val barHeight = size.height * amp
                            val x = idx * step + step / 2f
                            drawLine(
                                color = EmeraldHighlight,
                                start = Offset(x, (size.height - barHeight) / 2f),
                                end = Offset(x, (size.height + barHeight) / 2f),
                                strokeWidth = 2.5f
                            )
                        }
                    }
                }
            }
        }

        // CC Auto Captions Track
        Text("CC Auto Captions", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            captions.forEach { cap ->
                val widthDp = (((cap.endMs - cap.startMs) / 1000f) * 32f).coerceAtLeast(72f).dp
                Box(
                    modifier = Modifier
                        .width(widthDp)
                        .height(28.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(NeonPinkEffect.copy(alpha = 0.16f))
                        .border(1.dp, NeonPinkEffect.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(cap.text, color = TextPrimary, fontSize = 10.sp, maxLines = 1)
                }
            }
        }
    }
}
