package com.rs.aivideoeditorpro.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rs.aivideoeditorpro.domain.model.AudioTrackClip
import com.rs.aivideoeditorpro.domain.model.CaptionSegment
import com.rs.aivideoeditorpro.domain.model.ColorGradeParams
import com.rs.aivideoeditorpro.domain.model.EditorTool
import com.rs.aivideoeditorpro.domain.model.ExportSettings
import com.rs.aivideoeditorpro.domain.model.FilterPreset
import com.rs.aivideoeditorpro.domain.model.OverlayElement
import com.rs.aivideoeditorpro.domain.model.TransitionType
import com.rs.aivideoeditorpro.domain.model.VideoClip
import com.rs.aivideoeditorpro.engine.MediaProcessorEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

data class VideoEditorUiState(
    val videoClips: List<VideoClip> = emptyList(),
    val audioClips: List<AudioTrackClip> = emptyList(),
    val overlays: List<OverlayElement> = emptyList(),
    val captions: List<CaptionSegment> = emptyList(),
    val selectedClipId: String? = null,
    val activeTool: EditorTool = EditorTool.CUT_TRIM,
    val playheadMs: Long = 0L,
    val isPlaying: Boolean = false,
    val isExportSheetOpen: Boolean = false,
    val exportProgress: Float? = null,
    val exportResultMessage: String? = null
)

class VideoEditorViewModel(application: Application) : AndroidViewModel(application) {

    private val processor = MediaProcessorEngine(application)
    private val _uiState = MutableStateFlow(VideoEditorUiState())
    val uiState: StateFlow<VideoEditorUiState> = _uiState.asStateFlow()

    fun selectTool(tool: EditorTool) {
        _uiState.update { it.copy(activeTool = tool) }
    }

    fun selectClip(clipId: String) {
        _uiState.update { it.copy(selectedClipId = clipId) }
    }

    fun seekTo(positionMs: Long) {
        _uiState.update { it.copy(playheadMs = positionMs.coerceAtLeast(0L)) }
    }

    fun togglePlayPause() {
        _uiState.update { it.copy(isPlaying = !it.isPlaying) }
    }

    fun splitSelectedClipAtPlayhead() {
        val state = _uiState.value
        val targetId = state.selectedClipId ?: return
        val index = state.videoClips.indexOfFirst { it.id == targetId }
        if (index < 0) return

        val clip = state.videoClips[index]
        val clipStartOnTimeline = state.videoClips.take(index).sumOf { it.effectiveDurationMs }
        val splitOffsetMs = ((state.playheadMs - clipStartOnTimeline) * clip.speed).toLong()
        if (splitOffsetMs <= 300L || splitOffsetMs >= (clip.trimEndMs - clip.trimStartMs - 300L)) return

        val splitSourcePoint = clip.trimStartMs + splitOffsetMs
        val firstHalf = clip.copy(trimEndMs = splitSourcePoint)
        val secondHalf = clip.copy(
            id = java.util.UUID.randomUUID().toString(),
            title = "${clip.title} (Part 2)",
            trimStartMs = splitSourcePoint
        )

        val updated = state.videoClips.toMutableList().apply {
            removeAt(index)
            add(index, secondHalf)
            add(index, firstHalf)
        }
        _uiState.update { it.copy(videoClips = updated, selectedClipId = secondHalf.id) }
    }

    fun mergeWithNextClip() {
        val state = _uiState.value
        val targetId = state.selectedClipId ?: return
        val index = state.videoClips.indexOfFirst { it.id == targetId }
        if (index < 0 || index >= state.videoClips.lastIndex) return

        val current = state.videoClips[index]
        val next = state.videoClips[index + 1]
        val merged = current.copy(trimEndMs = current.trimEndMs + (next.trimEndMs - next.trimStartMs))

        val updated = state.videoClips.toMutableList().apply {
            removeAt(index + 1)
            set(index, merged)
        }
        _uiState.update { it.copy(videoClips = updated) }
    }

    fun updateSpeed(speed: Float) {
        updateSelectedClip { it.copy(speed = speed.coerceIn(0.25f, 4.0f)) }
    }

    fun updateFilter(preset: FilterPreset) {
        updateSelectedClip { it.copy(filterPreset = preset) }
    }

    fun updateTransition(transition: TransitionType) {
        updateSelectedClip { it.copy(transitionIn = transition) }
    }

    fun updateColorGrading(grade: ColorGradeParams) {
        updateSelectedClip { it.copy(colorGrade = grade) }
    }

    fun generateAutoCaptions() {
        val captions = processor.generateAutoCaptions(_uiState.value.videoClips)
        _uiState.update { it.copy(captions = captions) }
    }

    fun setExportSheetOpen(open: Boolean) {
        _uiState.update { it.copy(isExportSheetOpen = open, exportResultMessage = null) }
    }

    fun startExport(settings: ExportSettings) {
        val state = _uiState.value
        if (state.videoClips.isEmpty()) return

        viewModelScope.launch {
            _uiState.update { it.copy(exportProgress = 0.01f, exportResultMessage = null) }
            val outFile = File(
                getApplication<Application>().getExternalFilesDir(null),
                "RS_PRO_${settings.resolution.label}_${System.currentTimeMillis()}.mp4"
            )
            val result = processor.exportTimeline(
                videoClips = state.videoClips,
                audioClips = state.audioClips,
                overlays = state.overlays,
                outputFile = outFile,
                settings = settings,
                onProgress = { pct -> _uiState.update { it.copy(exportProgress = pct) } }
            )
            _uiState.update {
                it.copy(
                    exportProgress = null,
                    exportResultMessage = result.fold(
                        onSuccess = { file -> "Saved to ${file.name}" },
                        onFailure = { err -> err.localizedMessage ?: "Export error" }
                    )
                )
            }
        }
    }

    private fun updateSelectedClip(transform: (VideoClip) -> VideoClip) {
        val targetId = _uiState.value.selectedClipId ?: return
        _uiState.update { state ->
            state.copy(
                videoClips = state.videoClips.map { if (it.id == targetId) transform(it) else it }
            )
        }
    }
}
