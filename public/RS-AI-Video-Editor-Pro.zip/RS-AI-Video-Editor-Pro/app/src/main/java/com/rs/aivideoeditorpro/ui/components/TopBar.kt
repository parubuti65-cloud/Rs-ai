package com.rs.aivideoeditorpro.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rs.aivideoeditorpro.ui.theme.EmeraldHighlight
import com.rs.aivideoeditorpro.ui.theme.HairlineBorder
import com.rs.aivideoeditorpro.ui.theme.OrangeAccent
import com.rs.aivideoeditorpro.ui.theme.PremiumBlack
import com.rs.aivideoeditorpro.ui.theme.StudioSurface
import com.rs.aivideoeditorpro.ui.theme.TextPrimary

@Composable
fun RsTopBar(
    onExportClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(StudioSurface)
            .border(1.dp, HairlineBorder)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "RS",
                color = EmeraldHighlight,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                text = "AI VIDEO EDITOR PRO",
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.4.sp
            )
        }

        Button(
            onClick = onExportClick,
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = OrangeAccent,
                contentColor = PremiumBlack
            )
        ) {
            Text(
                text = "Export 4K",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
        }
    }
}
