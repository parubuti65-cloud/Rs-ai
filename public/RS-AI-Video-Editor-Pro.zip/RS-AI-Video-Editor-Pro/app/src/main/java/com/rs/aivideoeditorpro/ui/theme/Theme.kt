package com.rs.aivideoeditorpro.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val RsDarkColorScheme = darkColorScheme(
    primary = EmeraldHighlight,
    secondary = NeonPinkEffect,
    tertiary = OrangeAccent,
    background = PremiumBlack,
    surface = StudioSurface,
    surfaceVariant = StudioElevated,
    onPrimary = PremiumBlack,
    onSecondary = TextPrimary,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    outline = HairlineBorder
)

private val RsTypography = Typography(
    titleLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp,
        letterSpacing = (-0.2).sp,
        color = TextPrimary
    ),
    labelMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        color = TextSecondary
    ),
    bodySmall = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        color = TextSecondary
    )
)

@Composable
fun RsVideoEditorTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = RsDarkColorScheme,
        typography = RsTypography,
        content = content
    )
}
