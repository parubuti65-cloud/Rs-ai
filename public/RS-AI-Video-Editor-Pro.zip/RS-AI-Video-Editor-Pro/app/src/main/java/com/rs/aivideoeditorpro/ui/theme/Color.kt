package com.rs.aivideoeditorpro.ui.theme

import androidx.compose.ui.graphics.Color

// RS Premium Branding Palette
val PremiumBlack = Color(0xFF08090C)
val StudioSurface = Color(0xFF101218)
val StudioElevated = Color(0xFF171A23)
val HairlineBorder = Color(0x14FFFFFF)

val EmeraldHighlight = Color(0xFF10B981)
val EmeraldBright = Color(0xFF34D399)
val NeonPinkEffect = Color(0xFFFF2E93)
val OrangeAccent = Color(0xFFFF6B2C)

val TextPrimary = Color(0xFFF3F4F6)
val TextSecondary = Color(0xFF9CA3AF)
val TextMuted = Color(0xFF6B7280)
