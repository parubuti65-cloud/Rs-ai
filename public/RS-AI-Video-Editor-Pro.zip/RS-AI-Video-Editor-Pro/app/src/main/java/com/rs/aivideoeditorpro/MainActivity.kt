package com.rs.aivideoeditorpro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rs.aivideoeditorpro.ui.screens.VideoEditorScreen
import com.rs.aivideoeditorpro.ui.theme.RsVideoEditorTheme
import com.rs.aivideoeditorpro.ui.viewmodel.VideoEditorViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RsVideoEditorTheme {
                val editorViewModel: VideoEditorViewModel = viewModel()
                VideoEditorScreen(viewModel = editorViewModel)
            }
        }
    }
}
