package com.rs.aivideoeditorpro.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rs.aivideoeditorpro.domain.model.CaptionSegment
import com.rs.aivideoeditorpro.domain.model.OverlayElement
import com.rs.aivideoeditorpro.domain.model.VideoClip
import com.rs.aivideoeditorpro.ui.theme.EmeraldHighlight
import com.rs.aivideoeditorpro.ui.theme.HairlineBorder
import com.rs.aivideoeditorpro.ui.theme.NeonPinkEffect
import com.rs.aivideoeditorpro.ui.theme.PremiumBlack
import com.rs.aivideoeditorpro.ui.theme.StudioSurface
import com.rs.aivideoeditorpro.ui.theme.TextPrimary
import com.rs.aivideoeditorpro.ui.theme.TextSecondary

@Composable
fun VideoPreviewPlayer(
    activeClip: VideoClip?,
    activeOverlays: List<OverlayElement>,
    activeCaption: CaptionSegment?,
    playheadMs: Long,
    totalDurationMs: Long,
    isPlaying: Boolean,
    onTogglePlay: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(PremiumBlack)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(10.dp))
                .background(StudioSurface)
                .border(1.dp, HairlineBorder, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (activeClip == null) {
                Text("Import video or select a clip", color = TextSecondary, fontSize = 13.sp)
            } else {
                // ExoPlayer SurfaceView attaches here via AndroidView
                Text(
                    text = activeClip.title,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp
                )
            }

            // Live Text & Sticker Overlays
            activeOverlays.forEach { overlay ->
                Text(
                    text = overlay.text,
                    color = if (overlay.isSticker) NeonPinkEffect else Color(overlay.colorHex),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 20.dp)
                )
            }

            // Live Auto Caption Scrim
            if (activeCaption != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 14.dp, start = 16.dp, end = 16.dp)
                        .background(Color(0xCC08090C), RoundedCornerShape(6.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = activeCaption.text,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Transport Controls Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = formatTimecode(playheadMs),
                color = EmeraldHighlight,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )

            IconButton(onClick = onTogglePlay) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = TextPrimary
                )
            }

            Text(
                text = formatTimecode(totalDurationMs),
                color = TextSecondary,
                fontSize = 12.sp
            )
        }
    }
}

private fun formatTimecode(ms: Long): String {
    val totalSec = ms / 1000
    val mins = totalSec / 60
    val secs = totalSec % 60
    val centis = (ms % 1000) / 10
    return String.format("%02d:%02d.%02d", mins, secs, centis)
}
