package com.rs.aivideoeditorpro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rs.aivideoeditorpro.domain.model.EditorTool
import com.rs.aivideoeditorpro.ui.components.EditingToolbar
import com.rs.aivideoeditorpro.ui.components.ExportSheet
import com.rs.aivideoeditorpro.ui.components.MultiTrackTimeline
import com.rs.aivideoeditorpro.ui.components.RsTopBar
import com.rs.aivideoeditorpro.ui.components.VideoPreviewPlayer
import com.rs.aivideoeditorpro.ui.theme.EmeraldHighlight
import com.rs.aivideoeditorpro.ui.theme.NeonPinkEffect
import com.rs.aivideoeditorpro.ui.theme.PremiumBlack
import com.rs.aivideoeditorpro.ui.viewmodel.VideoEditorViewModel

@Composable
fun VideoEditorScreen(viewModel: VideoEditorViewModel) {
    val state by viewModel.uiState.collectAsState()
    val totalDuration = state.videoClips.sumOf { it.effectiveDurationMs }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PremiumBlack)
    ) {
        RsTopBar(onExportClick = { viewModel.setExportSheetOpen(true) })

        VideoPreviewPlayer(
            activeClip = state.videoClips.firstOrNull { it.id == state.selectedClipId } ?: state.videoClips.firstOrNull(),
            activeOverlays = state.overlays,
            activeCaption = state.captions.firstOrNull {
                state.playheadMs in it.startMs..it.endMs
            },
            playheadMs = state.playheadMs,
            totalDurationMs = totalDuration,
            isPlaying = state.isPlaying,
            onTogglePlay = viewModel::togglePlayPause,
            modifier = Modifier.weight(1f)
        )

        MultiTrackTimeline(
            videoClips = state.videoClips,
            audioClips = state.audioClips,
            captions = state.captions,
            selectedClipId = state.selectedClipId,
            onSelectClip = viewModel::selectClip
        )

        // Contextual Quick Actions for Active Tool
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            when (state.activeTool) {
                EditorTool.SPLIT_MERGE -> {
                    Button(
                        onClick = viewModel::splitSelectedClipAtPlayhead,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldHighlight, contentColor = PremiumBlack)
                    ) { Text("Split Clip") }
                    Button(
                        onClick = viewModel::mergeWithNextClip,
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPinkEffect)
                    ) { Text("Merge Next") }
                }
                EditorTool.AUTO_CAPTIONS -> {
                    Button(
                        onClick = viewModel::generateAutoCaptions,
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPinkEffect)
                    ) { Text("Generate Auto Captions") }
                }
                else -> Spacer(modifier = Modifier)
            }
        }

        EditingToolbar(
            activeTool = state.activeTool,
            onSelectTool = viewModel::selectTool
        )
    }

    if (state.isExportSheetOpen) {
        ExportSheet(
            exportProgress = state.exportProgress,
            resultMessage = state.exportResultMessage,
            onDismiss = { viewModel.setExportSheetOpen(false) },
            onStartExport = viewModel::startExport
        )
    }
}
