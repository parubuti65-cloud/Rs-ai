package com.rs.aivideoeditorpro.domain.model

import android.net.Uri
import java.util.UUID

enum class EditorTool {
    CUT_TRIM,
    SPLIT_MERGE,
    TRANSITIONS,
    FILTERS_FX,
    TEXT_STICKERS,
    MUSIC_AUDIO,
    AUTO_CAPTIONS,
    SPEED_CONTROL,
    COLOR_GRADING
}

enum class TransitionType(val ffmpegName: String, val label: String) {
    NONE("none", "Hard Cut"),
    DISSOLVE("fade", "Cross Dissolve"),
    FADE_BLACK("fadeblack", "Dip to Black"),
    WIPE_LEFT("wipeleft", "Kinetic Wipe"),
    NEON_GLITCH("pixelize", "Neon Pink Glitch")
}

enum class FilterPreset(val label: String) {
    ORIGINAL("Original"),
    EMERALD_CINEMA("Emerald Cinema"),
    NEON_PINK("Neon Pink FX"),
    ORANGE_GRADE("Orange Grade"),
    NOIR("Obsidian Noir")
}

enum class ExportResolution(val label: String, val width: Int, val height: Int, val bitrate: String) {
    FHD_1080P("1080P", 1920, 1080, "14M"),
    QHD_2K("2K", 2560, 1440, "24M"),
    UHD_4K("4K", 3840, 2160, "45M")
}

data class ColorGradeParams(
    val exposure: Float = 0f,      // -1.0f to 1.0f
    val contrast: Float = 1.0f,    // 0.5f to 1.8f
    val saturation: Float = 1.0f,  // 0.0f to 2.0f
    val temperature: Float = 0f,   // -1.0f to 1.0f
    val vignette: Float = 0f       // 0.0f to 1.0f
)

data class VideoClip(
    val id: String = UUID.randomUUID().toString(),
    val uri: Uri,
    val title: String,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long,
    val speed: Float = 1.0f,
    val transitionIn: TransitionType = TransitionType.NONE,
    val transitionDurationMs: Long = 600L,
    val filterPreset: FilterPreset = FilterPreset.ORIGINAL,
    val colorGrade: ColorGradeParams = ColorGradeParams()
) {
    val effectiveDurationMs: Long
        get() = ((trimEndMs - trimStartMs) / speed).toLong().coerceAtLeast(250L)
}

data class AudioTrackClip(
    val id: String = UUID.randomUUID().toString(),
    val uri: Uri,
    val title: String,
    val startOffsetMs: Long = 0L,
    val durationMs: Long,
    val volume: Float = 0.85f,
    val fadeInMs: Long = 500L,
    val fadeOutMs: Long = 500L,
    val waveformSamples: List<Float> = emptyList()
)

data class OverlayElement(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isSticker: Boolean = false,
    val startMs: Long,
    val endMs: Long,
    val normalizedX: Float = 0.5f,
    val normalizedY: Float = 0.25f,
    val colorHex: Long = 0xFFFFFFFF
)

data class CaptionSegment(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val startMs: Long,
    val endMs: Long
)

data class ExportSettings(
    val resolution: ExportResolution = ExportResolution.UHD_4K,
    val fps: Int = 60,
    val useHevc: Boolean = true
)
