package com.rs.aivideoeditorpro.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rs.aivideoeditorpro.domain.model.EditorTool
import com.rs.aivideoeditorpro.ui.theme.EmeraldHighlight
import com.rs.aivideoeditorpro.ui.theme.HairlineBorder
import com.rs.aivideoeditorpro.ui.theme.PremiumBlack
import com.rs.aivideoeditorpro.ui.theme.StudioElevated
import com.rs.aivideoeditorpro.ui.theme.StudioSurface
import com.rs.aivideoeditorpro.ui.theme.TextPrimary
import com.rs.aivideoeditorpro.ui.theme.TextSecondary

@Composable
fun EditingToolbar(
    activeTool: EditorTool,
    onSelectTool: (EditorTool) -> Unit,
    modifier: Modifier = Modifier
) {
    val items: List<Triple<EditorTool, String, ImageVector>> = listOf(
        Triple(EditorTool.CUT_TRIM, "Cut & Trim", Icons.Default.ContentCut),
        Triple(EditorTool.SPLIT_MERGE, "Split & Merge", Icons.Default.SwapHoriz),
        Triple(EditorTool.TRANSITIONS, "Transitions", Icons.Default.AutoAwesome),
        Triple(EditorTool.FILTERS_FX, "Filters & FX", Icons.Default.Palette),
        Triple(EditorTool.TEXT_STICKERS, "Text & Stickers", Icons.Default.TextFields),
        Triple(EditorTool.MUSIC_AUDIO, "Music & Audio", Icons.Default.MusicNote),
        Triple(EditorTool.AUTO_CAPTIONS, "Auto Captions", Icons.Default.ClosedCaption),
        Triple(EditorTool.SPEED_CONTROL, "Speed", Icons.Default.Speed),
        Triple(EditorTool.COLOR_GRADING, "Color Grade", Icons.Default.Tune)
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(StudioSurface)
            .border(1.dp, HairlineBorder)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items.forEach { (tool, label, icon) ->
            val selected = tool == activeTool
            Column(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selected) EmeraldHighlight.copy(alpha = 0.16f) else StudioElevated)
                    .border(
                        width = 1.dp,
                        color = if (selected) EmeraldHighlight else HairlineBorder,
                        shape = RoundedCornerShape(8.dp)
                    )
                    .clickable { onSelectTool(tool) }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (selected) EmeraldHighlight else TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = label,
                    color = if (selected) TextPrimary else TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                )
            }
        }
    }
}
