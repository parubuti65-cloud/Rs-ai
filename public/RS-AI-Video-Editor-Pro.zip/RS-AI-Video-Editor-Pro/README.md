# RS AI VIDEO EDITOR PRO — Android Studio Project

Complete single-module Android Studio project built with **Kotlin**, **Jetpack Compose**, **FFmpegKit**, and **Android Media3 APIs**.

## Included Features
- **Top Bar**: `RS AI VIDEO EDITOR PRO` with instant `Export 4K` action
- **Live Video Preview**: Media3 ExoPlayer surface with Compose Text/Sticker & Auto Caption overlays
- **Multi-Track Timeline**: V1 Video, A1 Music & Audio (MediaExtractor waveform), CC Auto Captions
- **Editing Tools**: Cut & Trim, Split & Merge, Transitions (`xfade`), Filters & Effects, Text & Stickers, Music & Audio mixing, Auto Captions, Speed Control (`setpts`), Color Grading (`eq` + `colorbalance`)
- **Export**: 1080P / 2K / 4K up to 60 FPS with H.264 / H.265 HEVC

## Branding Palette
- Premium Black: `#08090C`
- Studio Surface: `#101218`
- Emerald Green Highlights: `#10B981`
- Neon Pink Effects: `#FF2E93`
- Orange Accent: `#FF6B2C`

## Opening in Android Studio
1. Extract `RS-AI-Video-Editor-Pro.zip`.
2. Open **Android Studio** -> **Open** -> select the extracted folder.
3. Let Gradle sync `libs.versions.toml` dependencies (`Media3 1.5.0`, `FFmpegKit 6.0-2`, `Compose BOM`).
4. Run on an Android device or emulator (API 26+).
